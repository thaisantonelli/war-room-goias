WAR ROOM GOIÁS 2026 — PUBLICAÇÃO NO GITHUB PAGES

Repositório sugerido: war-room-goias

1. Entre em https://github.com e faça login como thaisantonelli.
2. Clique em New repository.
3. Nome: war-room-goias
4. Marque Public e clique em Create repository.
5. Clique em uploading an existing file.
6. Envie o arquivo index.html desta pasta.
7. Confirme em Commit changes.
8. Abra Settings > Pages.
9. Em Source, escolha Deploy from a branch.
10. Em Branch, escolha main e / (root), depois Save.

Endereço esperado:
https://thaisantonelli.github.io/war-room-goias/

Observação:
o conteúdo publicado será público. Não inclua bastidores confidenciais, dados pessoais ou hipóteses sensíveis sem revisão.
